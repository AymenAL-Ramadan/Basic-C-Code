#include <stdio.h>

/*Create a code the sum 5 + 10*/


void main()
{
	int x = 5;
	int f = 10;

	printf_s("The sum:%d \n", x + f);

	printf("The address of x:%d \n", &x);
	printf("The address of f:%d \n", &f);


	float X = 10.3;  // the integer X here is not the same intgere x.
	float F = 2.3;

	printf_s("The sum:%f\n", X + F);

}